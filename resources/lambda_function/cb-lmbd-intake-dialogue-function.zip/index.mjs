// Lex V2 Dialog Code Hook — SMS Intake (ordered validation + preserve name casing)
// Mirrors only "stage" to Amazon Connect contact attributes on every turn.
//
// Stages: need_name → need_phone_choice → (maybe) need_phone → need_zip → done
// - Uses inputTranscript to preserve exact casing for the name slot.
// - After 3 invalid attempts per field, returns Close (Fulfilled) with error flags in session.
// - If confirm_ok === "yes", sets phone = sessionAttributes.customer_number (as-is).

import {
  ConnectClient,
  UpdateContactAttributesCommand,
  GetContactAttributesCommand,
} from "@aws-sdk/client-connect";

const connect = new ConnectClient({}); // region auto from Lambda env

const MAX_ATTEMPTS = 3;
const ZIP_REGEX_US = /^\d{5}(-\d{4})?$/;
const NAME_REGEX = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]{0,24}$/u;
const INSTANCE_ID_FALLBACK = process.env.CONNECT_INSTANCE_ID ?? null;

export const handler = async (event, context) => {
  const intentName = event.sessionState?.intent?.name ?? "Intake";
  const slots = cloneSlots(event.sessionState?.intent?.slots ?? {});
  const sess = { ...(event.sessionState?.sessionAttributes ?? {}) };
  const inputRaw = event.inputTranscript ?? "";
  const inputTrim = normStr(inputRaw);
  const reqAttr = event.requestAttributes ?? {};
  let hydratedFromConnect = false;

  if (!sess.connect_contact_id && reqAttr.connect_contact_id) {
    sess.connect_contact_id = String(reqAttr.connect_contact_id);
  }
  if (!sess.connect_instance_id && reqAttr.connect_instance_id) {
    sess.connect_instance_id = String(reqAttr.connect_instance_id);
  }
  if (!sess.customer_number && reqAttr.customer_number) {
    sess.customer_number = String(reqAttr.customer_number);
  }
  if (!sess.connect_instance_id && INSTANCE_ID_FALLBACK) {
    sess.connect_instance_id = INSTANCE_ID_FALLBACK;
  }

  // hydrate returns true when it reads anything from Connect
  try {
    hydratedFromConnect = (await hydrateFromConnect(sess)) === true;
  } catch (err) {
    console.warn("hydrateFromConnect failed", err?.message || err);
  }

  if (!sess.stage && reqAttr.stage) {
    sess.stage = String(reqAttr.stage);
  }

  if (!sess.attempts_name) sess.attempts_name = "0";
  if (!sess.attempts_phone_choice) sess.attempts_phone_choice = "0";
  if (!sess.attempts_phone_input) sess.attempts_phone_input = "0";
  if (!sess.attempts_zip) sess.attempts_zip = "0";

  let firstname = normStr(safeGet(slots, "firstname"));
  let confirmOk = normStr(safeGet(slots, "confirm_ok"));
  let phone = normStr(safeGet(slots, "phone"));
  let zipcode = normStr(safeGet(slots, "zipcode"));

  const currentStage = sess.stage || "need_name";
  const inNameTurn = currentStage === "need_name";

  if (sess._init_ignored !== "1" && inNameTurn) {
    sess._init_ignored = "1";
    return await step("need_name", false);
  }

  // 1) NAME
  if (!firstname) {
    return await step("need_name", false);
  }

  const toValidate = normalizeNameForValidation(inNameTurn && inputTrim ? inputTrim : firstname);
  if (inNameTurn && !NAME_REGEX.test(toValidate)) {
    const badVal = inNameTurn && inputTrim ? inputTrim : firstname;
    const tries = bump(sess, "attempts_name");
    if (tries >= MAX_ATTEMPTS) {
      return await closeMaxAttempts("name", badVal);
    }
    safeClear(slots, "firstname");
    return await step("need_name", false);
  }

  if (inNameTurn) {
    safeSet(slots, "firstname", inputTrim ? inputTrim : firstname);
    reset(sess, "attempts_name");
  }

  // 2) PHONE CHOICE (yes/no)
  if (currentStage === "need_phone_choice") {
    const candidate = confirmOk ?? inputTrim;
    if (!candidate) {
      return await step("need_phone_choice", false);
    }
    if (!/^(yes|no)$/i.test(candidate)) {
      const tries = bump(sess, "attempts_phone_choice");
      if (tries >= MAX_ATTEMPTS) {
        return await closeMaxAttempts("phone_choice", candidate);
      }
      safeSet(slots, "confirm_ok", null);
      return await step("need_phone_choice", false);
    }
    confirmOk = candidate.toLowerCase();
    safeSet(slots, "confirm_ok", confirmOk);
  } else {
    if (!confirmOk && !phone && !zipcode && currentStage !== "need_phone_choice") {
      return await step("need_phone_choice", false);
    }
  }

  // If "yes", use customer_number
  if (/^yes$/i.test(confirmOk || "")) {
    const custRaw = sess.customer_number ?? reqAttr.customer_number ?? null;
    if (custRaw != null && String(custRaw).trim().length > 0) {
      safeSet(slots, "phone", String(custRaw));
    } else {
      safeSet(slots, "phone", null);
      return await step("need_phone", false);
    }
  }

  // 3) PREFERRED PHONE
  if (/^no$/i.test(confirmOk || "")) {
    if (!phone) {
      return await step("need_phone", false);
    }

    let digits = onlyDigits(phone);
    if (digits.length === 11 && digits.startsWith("1")) digits = digits.slice(1);

    if (digits.length !== 10) {
      const tries = bump(sess, "attempts_phone_input");
      if (tries >= MAX_ATTEMPTS) {
        return await closeMaxAttempts("phone_input", phone);
      }
      safeSet(slots, "phone", null);
      return await step("need_phone", false);
    }

    safeSet(slots, "phone", `+1${digits}`);
    reset(sess, "attempts_phone_input");
  }

  // 4) ZIP (optional; allow "skip")
  if (!zipcode) {
    return await step("need_zip", false);
  }
  if ((zipcode || "").toLowerCase() === "skip") {
    safeSet(slots, "zipcode", "-");
    reset(sess, "attempts_zip");
  } else if (!ZIP_REGEX_US.test(zipcode)) {
    const tries = bump(sess, "attempts_zip");
    if (tries >= MAX_ATTEMPTS) {
      return await closeMaxAttempts("zip", zipcode);
    }
    safeSet(slots, "zipcode", null);
    return await step("need_zip", false);
  } else {
    reset(sess, "attempts_zip");
  }

  // 5) DONE
  return await step("done", true);

  // ---------------- local helpers (inside handler) ----------------

  async function step(stage, isValid) {
    sess.stage = stage;
    sess.valid = String(!!isValid);

    let mirrorOk = true;
    try {
      await mirrorStageToConnect(sess);
    } catch (err) {
      mirrorOk = false;
      console.warn("mirrorStageToConnect failed", err?.message || err);
    }

    // Single comprehensive, non-PII log
    console.log(
      "LEXSTEP",
      JSON.stringify({
        ts: new Date().toISOString(),
        reqId: context.awsRequestId,
        intent: intentName,
        stage,
        valid: !!isValid,
        attempts: {
          name: Number(sess.attempts_name || 0),
          phone_choice: Number(sess.attempts_phone_choice || 0),
          phone_input: Number(sess.attempts_phone_input || 0),
          zip: Number(sess.attempts_zip || 0),
        },
        slots: {
          present: {
            firstname: !!firstname,
            confirm_ok: !!confirmOk,
            phone: !!phone,
            zipcode: !!zipcode,
          },
          lengths: {
            input_raw_len: (inputRaw || "").length,
            firstname_len: (firstname || "").length,
            phone_len: (phone || "").length,
            zipcode_len: (zipcode || "").length,
          },
        },
        states: {
          in_name_turn: inNameTurn,
          confirm_ok_state: confirmOk ? (/^yes$/i.test(confirmOk) ? "yes" : /^no$/i.test(confirmOk) ? "no" : "other") : "unset",
          customer_number_present: !!sess.customer_number,
        },
        contact: {
          instance_id: sess.connect_instance_id || null,
          contact_id: sess.connect_contact_id || null, // use this in Connect contact search
        },
        flags: {
          hydrated_from_connect: !!hydratedFromConnect,
          init_ignored: sess._init_ignored === "1",
          lambda_region: process.env.AWS_REGION || null,
        },
        mirror: mirrorOk ? "ok" : "failed",
      })
    );

    return {
      sessionState: {
        sessionAttributes: sess,
        intent: { name: intentName, slots, state: "InProgress" },
        dialogAction: { type: "Delegate" },
      },
      messages: [],
      requestAttributes: {},
    };
  }

  async function closeMaxAttempts(field, badValue) {
    const errKey = `too_many_attempts_${field}`;
    const lastBadKey = `last_bad_${field}`;

    sess.valid = "false";
    sess.stage = `failed_${field}`;
    sess.error = errKey;
    sess.error_field = field;
    if (badValue != null) sess[lastBadKey] = String(badValue);

    let mirrorOk = true;
    try {
      await mirrorStageToConnect(sess);
    } catch (err) {
      mirrorOk = false;
      console.warn("mirrorStageToConnect failed", err?.message || err);
    }

    // Final outcome log on failure (still without PII)
    console.log(
      "LEXSTEP",
      JSON.stringify({
        ts: new Date().toISOString(),
        reqId: context.awsRequestId,
        intent: intentName,
        stage: sess.stage,
        valid: false,
        error: errKey,
        error_field: field,
        attempts: {
          name: Number(sess.attempts_name || 0),
          phone_choice: Number(sess.attempts_phone_choice || 0),
          phone_input: Number(sess.attempts_phone_input || 0),
          zip: Number(sess.attempts_zip || 0),
        },
        contact: {
          instance_id: sess.connect_instance_id || null,
          contact_id: sess.connect_contact_id || null,
        },
        mirror: mirrorOk ? "ok" : "failed",
      })
    );

    return {
      sessionState: {
        sessionAttributes: sess,
        intent: { name: intentName, slots, state: "Fulfilled" },
        dialogAction: { type: "Close" },
      },
      messages: [],
      requestAttributes: {},
    };
  }
};

// ---------- Connect hydration + mirroring (module-scope) ----------

async function hydrateFromConnect(sess) {
  if (sess.stage) return false;

  const instanceId = sess.connect_instance_id;
  const contactId = sess.connect_contact_id; // InitialContactId
  if (!instanceId || !contactId) return false;

  const res = await connect.send(
    new GetContactAttributesCommand({
      InstanceId: instanceId,
      InitialContactId: contactId,
    })
  );
  const attrs = res?.Attributes ?? {};
  let hydrated = false;

  if (attrs.stage && !sess.stage) {
    sess.stage = String(attrs.stage);
    hydrated = true;
  }
  if (attrs.error) {
    sess.error = String(attrs.error);
    hydrated = true;
  }
  if (attrs.error_field) {
    sess.error_field = String(attrs.error_field);
    hydrated = true;
  }
  if (attrs._init_ignored && !sess._init_ignored) {
    sess._init_ignored = String(attrs._init_ignored);
    hydrated = true;
  }

  return hydrated;
}

async function mirrorStageToConnect(sess) {
  const instanceId = sess.connect_instance_id;
  const contactId = sess.connect_contact_id; // InitialContactId
  if (!instanceId || !contactId) return;

  const attrs = {
    stage: String(sess.stage || ""),
    error: String(sess.error || ""),
    error_field: String(sess.error_field || ""),
    _init_ignored: String(sess._init_ignored || ""),
  };

  await connect.send(
    new UpdateContactAttributesCommand({
      InstanceId: instanceId,
      InitialContactId: contactId,
      Attributes: attrs,
    })
  );
}

// ---------- utilities ----------
function normalizeNameForValidation(s) {
  if (!s) return s;
  return String(s)
    .replace(/[\u2018\u2019\u02BC]/g, "'")
    .replace(/[\u2010\u2011\u2012\u2013\u2014]/g, "-")
    .replace(/\s+/g, " ")
    .trim();
}

function normStr(v) {
  if (v == null) return null;
  const s = String(v).trim();
  return s.length ? s : null;
}

function cloneSlots(slots) {
  return JSON.parse(JSON.stringify(slots || {}));
}

function safeGet(slots, name) {
  const v = slots?.[name]?.value;
  return v?.originalValue ?? v?.interpretedValue ?? null;
}

function safeSet(slots, name, v) {
  if (!slots[name]) {
    slots[name] = {
      shape: "Scalar",
      value: { originalValue: null, interpretedValue: null, resolvedValues: [] },
    };
  }
  slots[name].value.originalValue = v;
  slots[name].value.interpretedValue = v;
  slots[name].value.resolvedValues = v ? [String(v)] : [];
}

function safeClear(slots, name) {
  if (!slots?.[name]) return;
  slots[name] = {
    shape: "Scalar",
    value: { originalValue: null, interpretedValue: null, resolvedValues: [] },
  };
}

function bump(sess, k) {
  const n = Number(sess[k] || 0) + 1;
  sess[k] = String(n);
  return n;
}

function reset(sess, k) {
  delete sess[k];
}

function onlyDigits(s) {
  return (s ?? "").replace(/\D+/g, "");
}