import json
import base64
import boto3
from datetime import datetime
from typing import Dict, Any, Set
import os

cases_client = boto3.client('connectcases')
connect_client = boto3.client('connect')

_FIELD_CACHE = None
_FIELD_NAMES_CACHE = None
_CACHE_TIMESTAMP = None
CACHE_TTL_SECONDS = 3600

def _get_required_env(var_name: str) -> str:
    value = os.environ.get(var_name)
    if not value:
        raise ValueError(f"Required environment variable {var_name} is not set")
    return value

DOMAIN_ID = _get_required_env('DOMAIN_ID')
INSTANCE_ID = _get_required_env('INSTANCE_ID')
GENERAL_SUPPORT_TEMPLATE_ID = _get_required_env('GENERAL_SUPPORT_TEMPLATE_ID')

EXCLUDED_FIELDS = {
    'case_id',  # Duplicate of case_id in metadata
}

_TEMPLATE_FIELDS_CACHE = {}
_TEMPLATE_CACHE_TIMESTAMP = {}


def get_template_fields(domain_id: str, template_id: str) -> tuple[Set[str], Dict[str, str]]:
    """Get fields for a specific template via get_layout API"""
    global _TEMPLATE_FIELDS_CACHE, _TEMPLATE_CACHE_TIMESTAMP

    cache_key = f"{domain_id}:{template_id}"
    current_time = datetime.now().timestamp()

    if cache_key in _TEMPLATE_FIELDS_CACHE and cache_key in _TEMPLATE_CACHE_TIMESTAMP:
        cache_age = current_time - _TEMPLATE_CACHE_TIMESTAMP[cache_key]
        if cache_age < CACHE_TTL_SECONDS:
            cached = _TEMPLATE_FIELDS_CACHE[cache_key]
            print(f"DEBUG: Using cached template fields ({len(cached[0])} fields, age: {cache_age:.0f}s)")
            return cached

    print(f"DEBUG: Fetching fields for template {template_id} from Cases API")
    field_ids = set()
    field_names = {}

    try:
        # Get template to find associated layout
        template_response = cases_client.get_template(
            domainId=domain_id,
            templateId=template_id
        )

        layout_id = template_response.get('layoutConfiguration', {}).get('defaultLayout')

        if layout_id:
            # Get layout to find fields
            layout_response = cases_client.get_layout(
                domainId=domain_id,
                layoutId=layout_id
            )

            # Extract fields from layout content sections
            content = layout_response.get('content', {})

            # Process basic layout sections
            for section in content.get('basic', {}).get('topPanel', {}).get('sections', []):
                for field_group in section.get('fieldGroup', {}).get('fields', []):
                    field_id = field_group.get('id')
                    if field_id:
                        field_ids.add(field_id)

            for section in content.get('basic', {}).get('moreInfo', {}).get('sections', []):
                for field_group in section.get('fieldGroup', {}).get('fields', []):
                    field_id = field_group.get('id')
                    if field_id:
                        field_ids.add(field_id)

        # Also get required fields from template
        for field in template_response.get('requiredFields', []):
            field_id = field.get('fieldId')
            if field_id:
                field_ids.add(field_id)

        # Get field names for ALL fields (with pagination)
        if field_ids:
            next_token = None
            while True:
                params = {'domainId': domain_id, 'maxResults': 100}
                if next_token:
                    params['nextToken'] = next_token

                fields_response = cases_client.list_fields(**params)

                for field in fields_response.get('fields', []):
                    fid = field.get('fieldId')
                    if fid in field_ids:
                        field_names[fid] = field.get('name', fid)

                next_token = fields_response.get('nextToken')
                if not next_token:
                    break

        print(f"DEBUG: Fetched {len(field_ids)} fields for template {template_id}, mapped {len(field_names)} names")

        _TEMPLATE_FIELDS_CACHE[cache_key] = (field_ids, field_names)
        _TEMPLATE_CACHE_TIMESTAMP[cache_key] = current_time

        return field_ids, field_names

    except Exception as e:
        print(f"ERROR: Failed to fetch template fields: {e}")
        import traceback
        traceback.print_exc()
        # Fall back to all fields if template fetch fails
        return get_all_case_fields(domain_id)


def get_all_case_fields(domain_id: str) -> tuple[Set[str], Dict[str, str]]:
    global _FIELD_CACHE, _FIELD_NAMES_CACHE, _CACHE_TIMESTAMP

    current_time = datetime.now().timestamp()
    if _FIELD_CACHE and _FIELD_NAMES_CACHE and _CACHE_TIMESTAMP:
        cache_age = current_time - _CACHE_TIMESTAMP
        if cache_age < CACHE_TTL_SECONDS:
            print(f"DEBUG: Using cached field list ({len(_FIELD_CACHE)} fields, age: {cache_age:.0f}s)")
            return _FIELD_CACHE, _FIELD_NAMES_CACHE

    print(f"DEBUG: Fetching field list from Cases API (domain: {domain_id})")
    field_ids = set()
    field_names = {}
    next_token = None

    try:
        while True:
            params = {'domainId': domain_id, 'maxResults': 100}
            if next_token:
                params['nextToken'] = next_token

            response = cases_client.list_fields(**params)

            for field in response.get('fields', []):
                field_id = field.get('fieldId')
                field_name = field.get('name', field_id)
                if field_id:
                    field_ids.add(field_id)
                    field_names[field_id] = field_name

            next_token = response.get('nextToken')
            if not next_token:
                break

        print(f"DEBUG: Fetched {len(field_ids)} fields from Cases API")

        _FIELD_CACHE = field_ids
        _FIELD_NAMES_CACHE = field_names
        _CACHE_TIMESTAMP = current_time

        return field_ids, field_names

    except Exception as e:
        print(f"ERROR: Failed to fetch fields from Cases API: {e}")
        return (
            _FIELD_CACHE if _FIELD_CACHE else set(),
            _FIELD_NAMES_CACHE if _FIELD_NAMES_CACHE else {}
        )


def standardize_timestamp(ts_string: str) -> str:
    if not ts_string:
        return ''

    try:
        if 'T' in ts_string:
            if '.' in ts_string:
                parts = ts_string.split('.')
                fractional = parts[1].rstrip('Z')[:3]
                return f"{parts[0]}.{fractional}Z"
            else:
                return ts_string.rstrip('Z') + '.000Z'

        return ts_string
    except:
        return ts_string


def get_agent_username(agent_arn: str, instance_id: str) -> str:
    try:
        if '/agent/' in agent_arn:
            agent_id = agent_arn.split('/agent/')[-1]

            response = connect_client.describe_user(
                UserId=agent_id,
                InstanceId=instance_id
            )

            user = response.get('User', {})
            display_name = user.get('IdentityInfo', {}).get('DisplayName')
            username = user.get('Username')

            return display_name or username or agent_id
    except Exception as e:
        print(f"Could not get username for agent {agent_arn}: {e}")
        if '/agent/' in agent_arn:
            return agent_arn.split('/agent/')[-1]

    return ''


def extract_value(field_data: Dict) -> str:
    if not field_data:
        return ''

    value = field_data.get('value', {})

    if 'stringValue' in value:
        return value['stringValue']
    elif 'doubleValue' in value:
        return str(value['doubleValue'])
    elif 'booleanValue' in value:
        return str(value['booleanValue'])
    elif 'userArnValue' in value:
        arn = value['userArnValue']
        if '/agent/' in arn:
            return arn.split('/agent/')[-1]
        return arn
    elif 'emptyValue' in value:
        return ''

    return ''


def get_full_case(case_id: str, domain_id: str, field_ids: Set[str]) -> Dict:
    try:
        print(f"DEBUG: Fetching full case data for case_id: {case_id} with {len(field_ids)} fields")

        fields_param = [{'id': fid} for fid in field_ids]

        response = cases_client.get_case(
            caseId=case_id,
            domainId=domain_id,
            fields=fields_param
        )

        fields_array = response.get('fields', [])
        fields_dict = {field['id']: field for field in fields_array}

        print(f"DEBUG: Fetched {len(fields_dict)} fields from GetCase API")
        return fields_dict

    except Exception as e:
        print(f"ERROR: Failed to fetch case {case_id} from Cases API: {e}")
        import traceback
        traceback.print_exc()
        return {}


def flatten_case_event(event_data: Dict, domain_id: str, instance_id: str) -> Dict:
    detail = event_data.get('detail', {})
    event_type = detail.get('eventType', '')
    case = detail.get('case', {})
    template_id = case.get('templateId', '')

    # Filter by template if GENERAL_SUPPORT_TEMPLATE_ID is set
    if GENERAL_SUPPORT_TEMPLATE_ID and template_id != GENERAL_SUPPORT_TEMPLATE_ID:
        print(f"DEBUG: Skipping case with template {template_id} (not General Support)")
        return None

    # Get fields for specific template or all fields
    if template_id:
        all_field_ids, field_names = get_template_fields(domain_id, template_id)
    else:
        all_field_ids, field_names = get_all_case_fields(domain_id)

    performed_by = detail.get('performedBy', {})
    if 'user' in performed_by:
        user_arn = performed_by['user'].get('userArn', '')
        if '/instance/' in user_arn:
            extracted_instance_id = user_arn.split('/instance/')[-1].split('/')[0]
            if extracted_instance_id:
                instance_id = extracted_instance_id

    agent_username = ''
    if 'user' in performed_by:
        user_arn = performed_by['user'].get('userArn', '')
        if instance_id:
            agent_username = get_agent_username(user_arn, instance_id)

    if not agent_username:
        case = detail.get('case', {})
        fields = case.get('fields', {})

        if 'last_updated_user' in fields:
            user_value = fields['last_updated_user'].get('value', {})

            user_ref = None
            if 'userArnValue' in user_value:
                user_ref = user_value['userArnValue']
            elif 'stringValue' in user_value:
                user_ref = user_value['stringValue']

            if user_ref:
                if '/' not in user_ref:
                    user_arn = f"arn:aws:connect:us-east-1:477686591640:instance/{instance_id}/agent/{user_ref}"
                else:
                    user_arn = user_ref
                    if '/instance/' in user_arn:
                        instance_id = user_arn.split('/instance/')[-1].split('/')[0]

                agent_username = get_agent_username(user_arn, instance_id)

    flat_event = {
        'timestamp': standardize_timestamp(event_data.get('time', '')),
        'event_id': event_data.get('id', ''),
        'event_type': event_type,
        'region': event_data.get('region', 'us-east-1'),
        'performed_by_agent': agent_username
    }

    case_id = case.get('caseId', '')

    details = {
        'case_id': case_id,
        'template_id': template_id,
        'case_created_datetime': standardize_timestamp(case.get('createdDateTime', ''))
    }

    full_case_fields = get_full_case(case_id, domain_id, all_field_ids)

    for field_id in all_field_ids:
        if field_id in EXCLUDED_FIELDS:
            print(f"DEBUG: Skipping excluded field: {field_id}")
            continue

        field_name = field_names.get(field_id, field_id)

        if field_id in full_case_fields:
            value = extract_value(full_case_fields[field_id])

            if 'datetime' in field_name.lower() or 'date' in field_name.lower() or \
                    'datetime' in field_id.lower() or 'date' in field_id.lower():
                value = standardize_timestamp(value)

            details[field_name] = value
        else:
            details[field_name] = ''

    flat_event['details'] = details

    return flat_event


def lambda_handler(event, context):
    output_records = []

    for record in event['records']:
        try:
            payload = base64.b64decode(record['data']).decode('utf-8')

            event_data = json.loads(payload)

            flattened_event = flatten_case_event(event_data, DOMAIN_ID, INSTANCE_ID)

            # Skip if template doesn't match (flatten_case_event returns None)
            if flattened_event is None:
                output_records.append({
                    'recordId': record['recordId'],
                    'result': 'Dropped',
                    'data': record['data']
                })
                continue

            flattened_payload = json.dumps(flattened_event) + '\n'
            encoded_payload = base64.b64encode(flattened_payload.encode('utf-8')).decode('utf-8')

            output_records.append({
                'recordId': record['recordId'],
                'result': 'Ok',
                'data': encoded_payload
            })

        except Exception as e:
            print(f"Error processing record {record['recordId']}: {e}")
            import traceback
            traceback.print_exc()

            output_records.append({
                'recordId': record['recordId'],
                'result': 'ProcessingFailed',
                'data': record['data']
            })

    return {
        'records': output_records
    }
