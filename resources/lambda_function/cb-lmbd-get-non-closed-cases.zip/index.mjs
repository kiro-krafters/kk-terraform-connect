// package.json: { "type": "module", "dependencies": { "@aws-sdk/client-connectcases": "^3.x" } }
import { ConnectCasesClient, SearchCasesCommand } from "@aws-sdk/client-connectcases";

const client = new ConnectCasesClient({});

// Simple structured logger
const log = (level, where, data = {}) => console.log(JSON.stringify({ level, where, ...data }));

export const handler = async (event, context) => {
  const reqId    = context?.awsRequestId;
  const domainId = process.env.CASES_DOMAIN_ID;

  // Read the ProfileArn passed from the Connect flow
  const profileArn = event?.Details?.ContactData?.Attributes?.ProfileArn?.trim() || "";

  log("INFO", "init", {
    reqId,
    awsRegion: process.env.AWS_REGION,
    hasDomainId: !!domainId,
    hasProfileArn: !!profileArn
  });

  if (!domainId || !profileArn) {
    log("WARN", "missing_inputs", {
      reqId,
      domainIdPresent: !!domainId,
      profileArnPresent: !!profileArn
    });
    return { error: "Missing domainId/profileArn", cases_any: "false" };
  }

  let nextToken;
  let page = 0;
  const pageSize = 50;

  try {
    do {
      page += 1;
      log("INFO", "search_page_start", {
        reqId, page, pageSize, nextTokenPresent: !!nextToken
      });

      const resp = await client.send(new SearchCasesCommand({
        domainId,
        fields: [
          { id: "case_id" },
          { id: "status" },
          { id: "customer_id" },
          { id: "created_datetime" }
        ],
        maxResults: pageSize,
        nextToken
      }));

      const items = resp.cases ?? [];
      
      log("INFO", "search_page_result", {
        reqId, 
        page, 
        itemsReturned: items.length, 
        nextTokenPresent: !!resp.nextToken
      });

      // Filter cases by customer_id in JavaScript
      for (let idx = 0; idx < items.length; idx++) {
        const c = items[idx];

        // Flatten system fields (union type) into a simple map
        const rawFields = c.fields ?? [];
        const f = Object.fromEntries(
          rawFields.map(x => [x.id, x.value?.stringValue ?? x.value?.timestampValue ?? ""])
        );

        const customerId = String(f["customer_id"] ?? "").trim();
        const status = String(f["status"] ?? "").trim();
        const createdAt = String(f["created_datetime"] ?? "");
        const caseId = c.caseId ?? "";

        // Skip if customer_id doesn't match
        if (customerId !== profileArn) {
          continue;
        }

        // Found a matching customer_id, now check if it's not closed
        if (status.toLowerCase() !== "closed") {
          log("INFO", "match_found_non_closed", {
            reqId, 
            page, 
            index: idx, 
            caseIdSuffix: caseId.slice(-6), 
            status,
            createdAt
          });
          return {
            cases_any: "true",
            last_case_id: caseId,
            last_case_status: status,
            last_case_created_at: createdAt
          };
        }
      }

      nextToken = resp.nextToken;
      log("INFO", "page_complete_no_match", { reqId, page, willContinue: !!nextToken });
    } while (nextToken);

    log("INFO", "no_non_closed_found", { reqId });
    return {
      cases_any: "false",
      last_case_id: "",
      last_case_status: "",
      last_case_created_at: ""
    };
  } catch (err) {
    log("ERROR", "unhandled_exception", {
      reqId,
      message: err?.message,
      name: err?.name,
      stack: err?.stack?.split("\n").slice(0, 3).join(" | ")
    });
    return {
      error: "SearchCases failed",
      cases_any: "false",
      last_case_id: "",
      last_case_status: "",
      last_case_created_at: ""
    };
  }
};