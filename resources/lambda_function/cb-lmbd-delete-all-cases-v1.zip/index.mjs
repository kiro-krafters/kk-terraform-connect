// package.json: { "type": "module", "dependencies": { "@aws-sdk/client-connectcases": "^3.x" } }

import {
  ConnectCasesClient,
  SearchCasesCommand,
  DeleteCaseCommand
} from "@aws-sdk/client-connectcases";

const client = new ConnectCasesClient({});

// Tuning knobs
const PAGE_SIZE = 100;
const DELETE_CONCURRENCY = 8;
const MAX_RETRIES = 5;

const log = (level, where, data = {}) =>
  console.log(JSON.stringify({ level, where, ...data }));

async function* listAllCases(domainId) {
  // No filter => ALL cases in the domain (dangerous; by design here)
  let nextToken;
  do {
    const resp = await client.send(new SearchCasesCommand({
      domainId,
      maxResults: PAGE_SIZE,
      nextToken
      // no "fields" needed for deletion; we only need caseId
    }));
    for (const c of (resp.cases ?? [])) {
      // Each "c" has c.caseId; we don't need fields for DeleteCase
      yield c.caseId;
    }
    nextToken = resp.nextToken;
  } while (nextToken);
}

async function deleteCase(domainId, caseId) {
  let delay = 150;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      await client.send(new DeleteCaseCommand({ domainId, caseId }));
      return { caseId, ok: true };
    } catch (e) {
      const code = e?.name || "";
      const retryable = /Throttling|TooManyRequests|Timeout|Internal|ServiceUnavailable/i.test(code);
      if (!retryable || attempt === MAX_RETRIES) {
        return { caseId, ok: false, error: e?.message || String(e), code };
      }
      await new Promise(r => setTimeout(r, delay + Math.floor(Math.random() * 100)));
      delay = Math.min(delay * 2, 2000);
    }
  }
}

export const handler = async (event) => {
  const domainId = process.env.CASES_DOMAIN_ID;
  if (!domainId) {
    return { ok: false, error: "Missing CASES_DOMAIN_ID env" };
  }

  const dryRun  = event?.dryRun !== false; // default true
  const confirm = String(event?.confirm || "");

  log("INFO", "start", { domainId, dryRun, confirm });

  // Enumerate all caseIds
  const caseIds = [];
  for await (const id of listAllCases(domainId)) {
    caseIds.push(id);
  }

  if (dryRun) {
    log("INFO", "dry_run_summary", { total: caseIds.length });
    return {
      ok: true,
      mode: "DRY_RUN",
      total: caseIds.length,
      sample: caseIds.slice(0, 15) // show first 15 ids
    };
  }

  if (confirm !== "DELETE_ALL_CASES") {
    return {
      ok: false,
      error: "Missing or wrong confirmation string. Set confirm:\"DELETE_ALL_CASES\" to proceed.",
      expectedConfirm: "DELETE_ALL_CASES",
      totalWouldDelete: caseIds.length
    };
  }

  // Delete with bounded concurrency
  let idx = 0;
  const results = Array(caseIds.length);
  const workers = Array(Math.min(DELETE_CONCURRENCY, caseIds.length))
    .fill(null)
    .map(async () => {
      while (idx < caseIds.length) {
        const i = idx++;
        const r = await deleteCase(domainId, caseIds[i]);
        results[i] = r;
        if (!r.ok) log("WARN", "delete_fail", { caseId: caseIds[i], error: r.error, code: r.code });
      }
    });

  await Promise.all(workers);

  const deleted = results.filter(r => r?.ok).length;
  const failed  = results.length - deleted;

  log("INFO", "done", { deleted, failed });

  return {
    ok: failed === 0,
    deleted,
    failed,
    // include up to 20 failures inline for quick inspection
    failures: results.filter(r => r && !r.ok).slice(0, 20)
  };
};
